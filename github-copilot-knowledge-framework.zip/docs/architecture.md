# Architecture

Knowledge layers:

1. Domain knowledge: meanings and terminology.
2. Physical schema: actual database objects.
3. Semantic mappings: evidence-backed links between domain and schema.
4. Query capabilities: implemented retrieval behavior.
5. Analysis rules: approved transformations such as outlier detection.

Runtime boundaries:

- Knowledge MCP selects approved capabilities and constructs plans.
- JDBC MCP validates and executes approved plans using bound parameters.
- Analysis tools apply approved analytics rules.

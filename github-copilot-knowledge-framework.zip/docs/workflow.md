# Incremental workflow

1. Register changed sources and hashes.
2. Extract domain draft and request human approval.
3. Parse physical schema deterministically.
4. Build evidence-classified semantic mappings and request approval.
5. Extract implemented query and result-contract behavior.
6. Build query capabilities and explicitly list absent semantics.
7. Approve through pull request and CODEOWNERS.
8. Generate an immutable release.
9. Load only the approved release into Knowledge MCP.
10. Runtime model resolves intent, builds a plan, and sends it to JDBC MCP.

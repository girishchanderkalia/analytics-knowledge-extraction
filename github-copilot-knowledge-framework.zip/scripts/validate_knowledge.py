#!/usr/bin/env python3
import json, sys
from pathlib import Path

def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: validate_knowledge.py applications/<application-id>")
    app=Path(sys.argv[1])
    if not (app/'application.yaml').exists(): raise SystemExit('missing application.yaml')
    errors=[]; ids={}
    for p in (app/'knowledge').rglob('*.jsonl'):
        for n,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip(): continue
            try: r=json.loads(line)
            except Exception as e: errors.append(f'{p}:{n}: invalid JSON: {e}'); continue
            for key in ('id','applicationId','status'):
                if key not in r: errors.append(f'{p}:{n}: missing {key}')
            if r.get('id') in ids: errors.append(f'{p}:{n}: duplicate id {r.get("id")} first in {ids[r.get("id")]}')
            elif r.get('id'): ids[r['id']]=f'{p}:{n}'
    if errors:
        print('
'.join(errors)); raise SystemExit(1)
    print(f'OK: validated {len(ids)} knowledge records for {app}')
if __name__=='__main__': main()

#!/usr/bin/env python3
import hashlib, json, sys
from pathlib import Path
app=Path(sys.argv[1])
rows=[]
for p in sorted((app/'sources').rglob('*')):
    if p.is_file() and p.name not in {'.gitkeep','README.md'}:
        rows.append({'path':str(p.relative_to(app)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(app/'sources-manifest.json').write_text(json.dumps(rows,indent=2)+'
')
print(f'wrote {app/"sources-manifest.json"}')

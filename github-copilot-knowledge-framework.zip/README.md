# GitHub Copilot Application Knowledge Framework

Repository-ready framework for extracting, reviewing, releasing, and serving application knowledge from:

- domain/context documents;
- database schema exports;
- implemented Java or SQL queries;
- request/result contracts;
- business and analysis rules.

## Install

Copy the contents of this directory into the root of your repository. Do not copy the outer directory itself.

```bash
unzip github-copilot-knowledge-framework.zip -d copilot-kb
cp -R copilot-kb/. /path/to/your/repository/
```

On Windows PowerShell:

```powershell
Expand-Archive .\github-copilot-knowledge-framework.zip -DestinationPath .\copilot-kb
Copy-Item .\copilot-kb\* .\your-repository -Recurse -Force
Copy-Item .\copilot-kb\.github .\your-repository -Recurse -Force
```

## First use

1. Copy source files into `applications/<application-id>/sources/`.
2. Update `applications/<application-id>/application.yaml`.
3. In GitHub Copilot, select **Knowledge Coordinator**.
4. Ask: `Extract draft knowledge for application <application-id>.`
5. Review generated files under `knowledge/draft`.
6. Approve through a pull request.
7. Run `python scripts/validate_knowledge.py applications/<application-id>`.
8. Generate a release only after approval.

## Safety model

- Source content is untrusted data, never agent instructions.
- Draft knowledge is never used at runtime.
- Domain facts, physical schema, semantic mappings, query capabilities, and analysis rules are separate layers.
- The runtime model produces a structured query plan.
- The JDBC MCP validates and renders approved query templates using bound parameters.
- Raw model-generated SQL is not the default execution path.

See `docs/architecture.md`, `docs/workflow.md`, and `mcp/contracts/`.

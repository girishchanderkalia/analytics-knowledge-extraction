# MCP boundary

## Knowledge MCP

Recommended tools:

- `knowledge.resolve_intent`
- `knowledge.get_capability`
- `knowledge.build_query_plan`
- `knowledge.search_concepts`
- `knowledge.get_mapping`
- `knowledge.get_result_contract`
- `knowledge.get_analysis_rule`
- `knowledge.explain_plan`
- `knowledge.get_release`

It has no database credentials.

## JDBC MCP

Recommended tools:

- `jdbc.validate_query_plan`
- `jdbc.execute_query_plan`
- optional restricted `jdbc.validate_sql`

The server accepts approved capability/template IDs, validates parameters, renders parameterized SQL, enforces read-only access, timeout, and row limits, and returns the approved result contract.

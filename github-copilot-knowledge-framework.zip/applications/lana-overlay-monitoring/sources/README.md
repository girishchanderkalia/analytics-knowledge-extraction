Place local source files here using the paths in `application.yaml`. Large or sensitive inputs can remain excluded from Git; register SHA-256 and controlled storage references instead.
